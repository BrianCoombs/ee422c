/*
package assignment3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MainBonus
{

    public static void main(String[] args) throws IOException
    {
        File input = new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\WebPage.html");
        Document doc = Jsoup.parse(input, "UTF-8", "http://example.com/");
        Elements content = doc.getElementsByClass("panels-flexible-row panels-flexible-row-5-main-row clearfix");
        Elements para = content.select("p");
        Element actSen = para.get(0);
        FileWriter fileWriter=new FileWriter(corpScraper);
        PrintWriter printWriter = new PrintWriter(fileWriter);

        File corpScraper=new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\CorpusScraper.txt");
        printWriter.println(actSen);
        printWriter.close();

        Scanner in = new Scanner(new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\CorpusScraper.txt"));
        String s = in.nextLine();
        s = s.replaceAll("<p>", "");
        s = s.replaceAll("</p>", "");
        s = s.replace(".", "");

        File corpScrap=new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\CorpusWebScrape.txt");
        FileWriter fileWriter1=new FileWriter(corpScrap);
        PrintWriter printWriter1 = new PrintWriter(fileWriter1);
        printWriter1.println(s);
        printWriter1.close();

        final GraphPoet nimoy = new GraphPoet(new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\CorpusWebScrape.txt"));
        System.out.println(nimoy.poem(new File("C:\\Users\\User\\IdeaProjects\\Assignment3.1\\InputScraper.txt")));
    }

}


*/